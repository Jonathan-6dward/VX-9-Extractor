
  # Text Extractor App

  This is a code bundle for Text Extractor App. The original project is available at https://www.figma.com/design/FHFosTczn0e7yXzTshrTN8/Text-Extractor-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  